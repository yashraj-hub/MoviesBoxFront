const TMDB_IMG = 'https://image.tmdb.org/t/p/w300'

export default function MovieCard({ movie }) {
  const poster = movie.posterPath || (movie.poster_path ? `${TMDB_IMG}${movie.poster_path}` : null)
  const year = (movie.releaseDate || movie.release_date)?.slice(0, 4)
  const rating = (movie.voteAverage ?? movie.vote_average)?.toFixed(1)
  return (
    <div className="group relative rounded-xl overflow-hidden bg-white/5 border border-white/10 hover:border-yellow-400/40 transition-all duration-300 cursor-pointer">
      {poster
        ? <img src={poster} alt={movie.title} className="w-full aspect-[2/3] object-cover group-hover:scale-105 transition-transform duration-500" loading="lazy" />
        : <div className="w-full aspect-[2/3] bg-white/5 flex items-center justify-center text-gray-600 text-xs">No Image</div>
      }
      <div className="p-3">
        <p className="text-[12px] font-bold text-white truncate">{movie.title}</p>
        <p className="text-[11px] text-gray-400 mt-1">{year} · ⭐ {rating}</p>
      </div>
    </div>
  )
}
