import MovieRow from '../components/MovieRow'
import HeroSection from '../components/HeroSection'
import TopTrending from '../components/TopTrending'

export default function BollywoodPage() {
  return (
    <div>
      <HeroSection category="bollywood" />
      <TopTrending category="bollywood" title="BOLLYWOOD TOP 10 TRENDING" />
      <div className="pt-16">
        <MovieRow title="Bollywood" endpoint="browse/bollywood" />
      </div>
    </div>
  )
}
