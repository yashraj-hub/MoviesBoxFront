import MovieRow from '../components/MovieRow'
import HeroSection from '../components/HeroSection'
import TopTrending from '../components/TopTrending'

export default function AnimationPage() {
  return (
    <div>
      <HeroSection category="animation" />
      <TopTrending category="animation" title="ANIMATION TOP 10 TRENDING" />
      <div className="pt-16">
        <MovieRow title="Animation" endpoint="browse/animation" />
      </div>
    </div>
  )
}
