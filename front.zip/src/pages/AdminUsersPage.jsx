import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Loader from '../components/Loader'

const TOKEN_KEY = 'moviesbox_token'
const API_BASE = '/api'

export default function AdminUsersPage() {
  const navigate = useNavigate()
  const [loading, setLoading] = useState(true)
  const [users, setUsers] = useState([])
  const [error, setError] = useState('')
  const token = localStorage.getItem(TOKEN_KEY)

  useEffect(() => {
    const load = async () => {
      try {
        const me = await fetch(`${API_BASE}/auth/me`, { headers: { Authorization: `Bearer ${token}` } }).then(r => r.json())
        if (me.user?.role !== 'admin') { navigate('/', { replace: true }); return }
        const data = await fetch(`${API_BASE}/admin/users`, { headers: { Authorization: `Bearer ${token}` } }).then(r => r.json())
        setUsers(data)
      } catch (err) { setError(err.message) }
      finally { setLoading(false) }
    }
    load()
  }, [navigate, token])

  const updateStatus = async (id, isActive) => {
    const data = await fetch(`${API_BASE}/admin/users/${id}/status`, {
      method: 'PATCH', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ isActive }),
    }).then(r => r.json())
    setUsers(u => u.map(x => x.id === id ? data.user : x))
  }

  const deleteUser = async (id) => {
    await fetch(`${API_BASE}/admin/users/${id}`, { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } })
    setUsers(u => u.filter(x => x.id !== id))
  }

  const forceLogout = async (userId, tokenId) => {
    const data = await fetch(`${API_BASE}/admin/users/${userId}/sessions/${tokenId}`, {
      method: 'DELETE', headers: { Authorization: `Bearer ${token}` },
    }).then(r => r.json())
    setUsers(u => u.map(x => x.id === userId ? data.user : x))
  }

  if (loading) return <Loader />

  const na = v => v || 'n/a'

  return (
    <div className="pt-24 px-4 md:px-12 pb-20">
      <h1 className="font-heading text-5xl text-white mb-3">Admin Users</h1>
      <p className="text-gray-500 text-sm mb-10">{users.length} registered users</p>
      {error && <p className="text-red-400 text-sm mb-6">{error}</p>}
      <div className="grid gap-6">
        {users.map(user => {
          const c = user.signupContext?.client
          const s = user.signupContext?.server
          return (
            <div key={user.id} className="rounded-2xl border border-white/10 bg-white/[0.02] p-7">
              {/* Header */}
              <div className="flex items-start justify-between gap-6 mb-6">
                <div>
                  <p className="font-black text-white uppercase tracking-widest text-base mb-1">{user.fullName}</p>
                  <p className="text-gray-500 text-xs tracking-wide">{user.email} · {user.userId}</p>
                  <div className="flex gap-3 mt-4">
                    <span className={`text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full ${user.role === 'admin' ? 'bg-yellow-400/20 text-yellow-400' : 'bg-white/10 text-gray-400'}`}>{user.role}</span>
                    <span className={`text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full ${user.isActive ? 'bg-green-400/20 text-green-400' : 'bg-red-400/20 text-red-400'}`}>{user.isActive ? 'Active' : 'Inactive'}</span>
                  </div>
                </div>
                <p className="text-[10px] text-gray-600 shrink-0 font-bold tracking-widest">{user.createdAt ? new Date(user.createdAt).toLocaleDateString() : ''}</p>
              </div>

              {/* Device info */}
              {c?.userAgent && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 p-5 rounded-xl bg-white/[0.03] border border-white/5">
                  {[
                    ['Platform', na(c.platform)],
                    ['Language', na(c.language)],
                    ['Timezone', na(c.timezone)],
                    ['Screen', na(c.screen)],
                    ['Device Memory', c.deviceMemory ? `${c.deviceMemory} GB` : 'n/a'],
                    ['CPU Cores', c.hardwareConcurrency ?? 'n/a'],
                    ['Connection', na(c.connection)],
                    ['IP', na(s?.ip)],
                  ].map(([label, val]) => (
                    <div key={label} className="space-y-1">
                      <p className="text-[9px] uppercase tracking-widest text-gray-500 font-bold">{label}</p>
                      <p className="text-[12px] text-gray-300 truncate font-medium">{val}</p>
                    </div>
                  ))}
                </div>
              )}

              {/* Sessions */}
              <div className="mb-8">
                <p className="text-[11px] uppercase tracking-widest text-yellow-400 font-black mb-4">
                  Active Sessions ({user.sessions?.length || 0}/2)
                </p>
                {user.sessions?.length > 0 ? (
                  <div className="space-y-2">
                    {user.sessions.map(session => (
                      <div key={session.tokenId} className="flex items-center justify-between gap-4 p-3 rounded-xl bg-white/[0.03] border border-white/5">
                        <div className="space-y-0.5">
                          <p className="text-[12px] text-gray-200 font-medium">{session.platform || 'Unknown Device'} · {session.ip || 'n/a'}</p>
                          <p className="text-[10px] text-gray-500 font-bold">{session.loggedInAt ? new Date(session.loggedInAt).toLocaleString() : ''}</p>
                        </div>
                        <button onClick={() => forceLogout(user.id, session.tokenId)}
                          className="text-[10px] font-black uppercase tracking-widest px-4 py-2 rounded-lg border border-red-400/30 bg-red-400/10 text-red-400 hover:bg-red-400/20 transition-all">
                          Force Logout
                        </button>
                      </div>
                    ))}
                  </div>
                ) : <p className="text-[11px] text-gray-600 italic">No active sessions</p>}
              </div>

              {/* Actions */}
              <div className="flex gap-3">
                <button onClick={() => updateStatus(user.id, !user.isActive)}
                  className="text-[10px] font-black uppercase tracking-widest px-6 py-3 rounded-xl border border-white/10 bg-white/5 text-gray-300 hover:text-white hover:bg-white/10 transition-all">
                  {user.isActive ? 'Make Inactive' : 'Make Active'}
                </button>
                {user.role !== 'admin' && (
                  <button onClick={() => deleteUser(user.id)}
                    className="text-[10px] font-black uppercase tracking-widest px-6 py-3 rounded-xl border border-red-400/20 bg-red-400/5 text-red-400 hover:bg-red-400/10 transition-all">
                    Delete User
                  </button>
                )}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
