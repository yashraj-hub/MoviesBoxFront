import { useState } from 'react'
import MovieCard from '../components/MovieCard'

const TOKEN_KEY = 'moviesbox_token'
const API_BASE = '/api'

export default function SearchPage() {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState([])
  const [loading, setLoading] = useState(false)
  const [searched, setSearched] = useState(false)
  const [source, setSource] = useState('')
  const [total, setTotal] = useState(null)
  const token = localStorage.getItem(TOKEN_KEY)

  const handleSearch = async (e) => {
    e.preventDefault()
    if (!query.trim() || query.trim().length < 2) return
    setLoading(true); setSearched(true)
    const d = await fetch(`${API_BASE}/search?q=${encodeURIComponent(query.trim())}`, {
      headers: { Authorization: `Bearer ${token}` },
    }).then(r => r.json()).catch(() => ({}))
    setResults(d.results || [])
    setSource(d.source || '')
    setTotal(d.totalResults ?? d.total_results ?? null)
    setLoading(false)
  }

  return (
    <div className="pt-24 px-4 md:px-12">
      <h1 className="font-heading text-4xl text-white mb-6">Search</h1>
      <form onSubmit={handleSearch} className="flex gap-3 mb-8 max-w-xl">
        <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search movies..."
          className="flex-1 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder-gray-500 focus:border-yellow-400 focus:outline-none" />
        <button type="submit" disabled={loading}
          className="px-6 py-3 rounded-2xl bg-yellow-400 text-black text-sm font-black uppercase tracking-widest hover:bg-yellow-300 disabled:opacity-50 transition-all">
          {loading ? '...' : 'Search'}
        </button>
      </form>
      {searched && (
        <>
          <p className="text-[10px] uppercase tracking-widest text-gray-500 mb-4">
            {total != null ? `${total.toLocaleString()} results` : ''}{source ? ` · source: ${source}` : ''}
          </p>
          {results.length === 0 && !loading
            ? <p className="text-gray-600">No results found.</p>
            : <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-3">
                {results.map(m => <MovieCard key={m.tmdbId || m.id} movie={m} />)}
              </div>
          }
        </>
      )}
    </div>
  )
}
