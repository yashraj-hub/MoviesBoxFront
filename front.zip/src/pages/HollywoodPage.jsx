import MovieRow from '../components/MovieRow'
import HeroSection from '../components/HeroSection'
import TopTrending from '../components/TopTrending'

export default function HollywoodPage() {
  return (
    <div>
      <HeroSection category="hollywood" />
      <TopTrending category="hollywood" title="HOLLYWOOD TOP 10 TRENDING" />
      <div className="pt-16">
        <MovieRow title="Hollywood" endpoint="browse/hollywood" />
      </div>
    </div>
  )
}
