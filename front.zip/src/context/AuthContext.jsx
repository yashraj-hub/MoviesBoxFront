import { createContext, useContext, useEffect, useState } from 'react'

const TOKEN_KEY = 'moviesbox_token'
const API_BASE = '/api'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(undefined) // undefined = loading, null = logged out

  useEffect(() => {
    const token = localStorage.getItem(TOKEN_KEY)
    if (!token) { setUser(null); return }
    fetch(`${API_BASE}/auth/me`, { headers: { Authorization: `Bearer ${token}` } })
      .then(res => res.json())
      .then(data => setUser(data.user || null))
      .catch(() => { localStorage.removeItem(TOKEN_KEY); setUser(null) })
  }, [])

  const logout = async () => {
    const token = localStorage.getItem(TOKEN_KEY)
    try {
      await fetch(`${API_BASE}/auth/logout`, { method: 'POST', headers: { Authorization: `Bearer ${token}` } })
    } catch (_) {}
    localStorage.removeItem(TOKEN_KEY)
    setUser(null)
  }

  return (
    <AuthContext.Provider value={{ user, setUser, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)
