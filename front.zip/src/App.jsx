import {
  BrowserRouter,
  Navigate,
  Outlet,
  Route,
  Routes,
  useNavigate,
} from 'react-router-dom'
import Navbar from './components/Navbar'
import Loader from './components/Loader'
import { AuthProvider, useAuth } from './context/AuthContext'
import AuthPage from './pages/AuthPage'
import HomePage from './pages/HomePage'
import BollywoodPage from './pages/BollywoodPage'
import HollywoodPage from './pages/HollywoodPage'
import AnimationPage from './pages/AnimationPage'
import SearchPage from './pages/SearchPage'
import AdminUsersPage from './pages/AdminUsersPage'

const TOKEN_KEY = 'moviesbox_token'

// ── App ───────────────────────────────────────────────────────────────────────
function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/auth" element={<AuthPage />} />
          <Route element={<ProtectedRoute />}>
            <Route element={<AppShell />}>
              <Route index element={<HomePage />} />
              <Route path="bollywood" element={<BollywoodPage />} />
              <Route path="hollywood" element={<HollywoodPage />} />
              <Route path="animation" element={<AnimationPage />} />
              <Route path="search" element={<SearchPage />} />
              <Route path="admin" element={<AdminUsersPage />} />
            </Route>
          </Route>
          <Route path="*" element={<RootRedirect />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  )
}

function RootRedirect() {
  const token = localStorage.getItem(TOKEN_KEY)
  return <Navigate to={token ? '/' : '/auth'} replace />
}

// ── Protected Route ───────────────────────────────────────────────────────────
function ProtectedRoute() {
  const { user } = useAuth()
  if (user === undefined) return <Loader />
  if (user === null) return <Navigate to="/auth" replace />
  return <Outlet />
}

// ── App Shell ─────────────────────────────────────────────────────────────────
function AppShell() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()

  const handleLogout = async () => {
    await logout()
    navigate('/auth', { replace: true })
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">
      <Navbar user={user} onLogout={handleLogout} />
      <main>
        <Outlet />
      </main>
          </div>
  )
}

export default App
